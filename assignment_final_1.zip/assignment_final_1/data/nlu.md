## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- Hola

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [Mysore]{"entity": "location", "value": "Delhi"}
- show me a [mexican](cuisine) place in the [Kanpur](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [Ujjain](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [Bareilly](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [American](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Mathura](location)
- [More than 700](budget)
- [Rs. 300 to 700](budget)
- [Lesser than Rs. 300](budget)
- Oh, sorry, in [Italy](location)
- in [Lucknow](location)
- I am looking for some restaurants in [Kolhapur](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [Bilaspur](location) in a [moderate]{"entity": "price", "value": "mid"} price range with [british](cuisine) food for [four]{"entity": "people", "value": "4"} people
- [Asansol](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- [Warangal](location)
- [Yes](send_mail)
- [yes please]{"entity": "send_mail", "value": "yes"}
- [yes](send_mail) sent it to [afroza25@gmail.com](email)
- [ya]{"entity": "send_mail", "value": "yes"} to [happy@gmail.com](email)
- [no](send_mail)
- [true](check_loc)
- [false](check_loc)
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [Noida](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [Dhanbad](location)
- search in [kanpur](location)
- [Rs 300 to 700](budget)
- [happyafroza25@gmail.com](email)
- search in belgaum[]{"entity": "location", "value": "belgaum"}
- [Lesser than Rs 300](budget)
- search in belgaum
- belgaum[]{"entity": "location", "value": "belgaum"}
- [yaa](send_mail)
- Im hungry. Looking out for some good restaurants
- [Guwahati](location)
- i will prefer [italian](cuisine)
- [yes](send_mail). Please send it to [ahbcdj@dkj.com{"entity": "email", "value": "ahbcdj@dkj.com"}
- Search retaurant in [Rishikesh](location)
- earch in [Ghaziabad](location)
- i will prefer [chines]{"entity": "cuisine", "value": "chinese"}
- [yes](send_mail)
- [yep]{"entity": "send_mail", "value": "yes"}
- [yeah]{"entity": "send_mail", "value": "yes"}
- [indeed]{"entity": "send_mail", "value": "yes"}
- [that's right]{"entity": "send_mail", "value": "yes"}
- [ok]{"entity": "send_mail", "value": "yes"}
- [great]{"entity": "send_mail", "value": "yes"}
- [right, thank you]{"entity": "send_mail", "value": "yes"}
- [great choice]{"entity": "send_mail", "value": "yes"}
- [sounds really good]{"entity": "send_mail", "value": "yes"}
- please send it to [xyz@a.com{"entity": "email", "value": "xyz@a.com"}
- Im hungry. Looking out for some good [chinese](cuisine) restaurants in [chandigarh](location)
- [i dont want]{"entity": "send_mail", "value": "no"}
- [no thanks]{"entity": "send_mail", "value": "no"}
- [please dont]{"entity": "send_mail", "value": "no"}
- in [mumbai](location)
- [yes please](send_mail){"entity": "send_mail", "value": "yes"}
- search restaurants in [dhanbad](location)
- [Mexican](cuisine)
- [Lesser than Rs 300](budget)
- [happyafroza25@gmail.com](email)

## intent:affirm
- [ok]{"entity": "send_mail", "value": "yes"}

## synonym:4
- four

## synonym:Delhi
- Mysore
- New Delhi

## synonym:bangalore
- Bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:mid
- moderate

## synonym:no
- i dont want
- no thanks
- please dont
- no[^\s]*
- na[^\s]*
- no please
- no thank u

## synonym:vegetarian
- veggie
- vegg

## synonym:yes
- yes please
- ya
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- great choice
- sounds really good
- ya[^\s]*
- yes[^\s]*
- correct
- thanks

## regex:email
- ^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}

## lookup:location
- Ahmedabad
- Bengaluru
- Chennai
- Delhi
- Hyderabad
- Kolkata
- Mumbai
- Pune
- Agra
- Ajmer
- Aligarh
- Amravati
- Amritsar
- Asansol
- Aurangabad
- Bareilly
- Belgaum
- Bhavnagar
- Bhiwandi
- Bhopal
- Bhubaneswar
- Bikaner
- Bilaspur
- Bokaro Steel City
- Chandigarh
- Coimbatore
- Cuttack
- Dehradun
- Dhanbad
- Bhilai
- Durgapur
- Dindigul
- Erode
- Faridabad
- Firozabad
- Ghaziabad
- Gorakhpur
- Gulbarga
- Guntur
- Gwalior
- Gurgaon
- Guwahati
- Hamirpur
- Hubli–Dharwad
- Indore
- Jabalpur
- Jaipur
- Jalandhar
- Jammu
- Jamnagar
- Jamshedpur
- Jhansi
- Jodhpur
- Kakinada
- Kannur
- Kanpur
- Karnal
- Kochi
- Kolhapur
- Kollam
- Kozhikode
- Kurnool
- Ludhiana
- Lucknow
- Madurai
- Malappuram
- Mathura
- Mangalore
- Meerut
- Moradabad
- Mysore
- Nagpur
- Nanded
- Nashik
- Nellore
- Noida
- Patna
- Pondicherry
- Purulia
- Prayagraj
- Raipur
- Rajkot
- Rajahmundry
- Ranchi
- Rourkela
- Salem
- Sangli
- Shimla
- Siliguri
- Solapur
- Srinagar
- Surat
- Thanjavur
- Thiruvananthapuram
- Thrissur
- Tiruchirappalli
- Tirunelveli
- Ujjain
- Bijapur
- Vadodara
- Varanasi
- Vasai-Virar City
- Vijayawada
- Visakhapatnam
- Vellore
- Warangal
