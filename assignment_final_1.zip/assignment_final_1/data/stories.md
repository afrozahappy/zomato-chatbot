## complete path
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - check_location
    - slot{"check_loc":"true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "Rs 300 to 700"}
    - slot{"budget": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_mail_needed
* affirm{"send_mail": "yes"}
    - slot{"send_mail": "yes"}
    - utter_ask_email
* restaurant_search{"email": "afroza25@gmail.com"}
    - slot{"email": "afroza25@gmail.com"} 
    - send_email 
    - utter_goodbye
    - export

## location specified
* greet
    - utter_greet
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - check_location
    - slot{"check_loc":"true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs 300"}
    - slot{"budget": "Lesser than Rs 300"}
    - action_search_restaurants
    - utter_ask_mail_needed
* affirm{"send_mail": "yes"}
    - slot{"send_mail": "yes"}
    - utter_ask_email
* restaurant_search{"email": "afroza25@gmail.com"}
    - slot{"email": "afroza25@gmail.com"} 
    - send_email 
    - utter_goodbye
    - export

## complete path 2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
    - slot{"location": "delhi"}
    - check_location
    - slot{"check_loc":"false"}
    - export

    
## happy_path
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "mumbai"}
    - slot{"cuisine": "italian"}
    - slot{"location": "mumbai"}
    - check_location
    - slot{"check_loc":"true"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_ask_mail_needed
* affirm{"send_mail": "no"}
    - slot{"send_mail": "no"}
    - utter_goodbye

##  interactive_story_1   
* greet
    - utter_greet
* restaurant_search{"location": "kanpur"}
    - slot{"location": "kanpur"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "Rs 300 to 700"}
    - slot{"budget": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "kanpur"}
    - utter_ask_mail_needed
* affirm{"send_mail": "yes"}
    - slot{"send_mail": "yes"}
    - utter_ask_email
* restaurant_search{"email": "happyafroza25@gmail.com"}
    - slot{"email": "happyafroza25@gmail.com"}
    - send_email
    - utter_goodbye


##interactive_story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "belgaum"}
    - slot{"location": "belgaum"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs 300"}
    - slot{"budget": "Lesser than Rs 300"}
    - action_search_restaurants
    - slot{"location": "belgaum"}
    - utter_ask_mail_needed
* affirm{"send_mail": "yaa"}
    - slot{"send_mail": "yaa"}
    - utter_ask_email
* restaurant_search{"email": "happyafroza25@gmail.com"}
    - slot{"email": "happyafroza25@gmail.com"}
    - send_email
    - utter_goodbye

##  interactive_story_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Guwahati"}
    - slot{"location": "Guwahati"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* restaurant_search{"budget": "Rs 300 to 700"}
    - slot{"budget": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Guwahati"}
    - utter_ask_mail_needed
* restaurant_search{"send_mail": "yes", "email": "ahbcdj@dkj.com"}
    - slot{"email": "ahbcdj@dkj.com"}
    - slot{"send_mail": "yes"}
    - send_email

##  location_and_cuisine_specified
* greet
    - utter_greet
* restaurant_search{"cuisine": "Rishikesh", "location": "Rishikesh"}
    - slot{"cuisine": "Rishikesh"}
    - slot{"location": "Rishikesh"}
    - check_location
    - slot{"check_loc": "false"}
    - utter_ask_location
* restaurant_search{"location": "Ghaziabad"}
    - slot{"location": "Ghaziabad"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"budget": "More than 700"}
    - slot{"budget": "More than 700"}
    - action_search_restaurants
    - slot{"location": "Ghaziabad"}
    - utter_ask_mail_needed
* restaurant_search{"send_mail": "yaa"}
    - slot{"send_mail": "yaa"}
    - utter_ask_email
* restaurant_search{"email": "xyz@a.com"}
    - slot{"email": "xyz@a.com"}
    - send_email

## happy_path_no_email
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs 300"}
    - slot{"budget": "Lesser than Rs 300"}
    - action_search_restaurants
    - slot{"location": "chandigarh"}
    - utter_ask_mail_needed
* restaurant_search{"send_mail": "no"}
    - slot{"send_mail": "no"}
    - utter_goodbye

## happy_path
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_budget
* restaurant_search{"budget": "Rs 300 to 700"}
    - slot{"budget": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_ask_mail_needed
* restaurant_search{"send_mail": "yes"}
    - slot{"send_mail": "yes"}
    - utter_ask_email
* restaurant_search{"email": "happyafroza25@gmail.com"}
    - slot{"email": "happyafroza25@gmail.com"}
    - send_email

## happy_path_no_mail
* greet
    - utter_greet
* restaurant_search{"location": "kanpur"}
    - slot{"location": "kanpur"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs 300"}
    - slot{"budget": "Lesser than Rs 300"}
    - action_search_restaurants
    - slot{"location": "kanpur"}
    - utter_ask_mail_needed
* restaurant_search{"send_mail": "no"}
    - slot{"send_mail": "no"}
    - utter_goodbye

## complete path
* greet
    - utter_greet
* restaurant_search{"location": "dhanbad"}
    - slot{"location": "dhanbad"}
    - check_location
    - slot{"check_loc": "true"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "Lesser than Rs 300"}
    - slot{"budget": "Lesser than Rs 300"}
    - action_search_restaurants
    - slot{"location": "dhanbad"}
    - utter_ask_mail_needed
* affirm{"send_mail": "yes"}
    - slot{"send_mail": "yes"}
    - utter_ask_email
* restaurant_search{"email": "happyafroza25@gmail.com"}
    - slot{"email": "happyafroza25@gmail.com"}
    - send_email
    - utter_goodbye
