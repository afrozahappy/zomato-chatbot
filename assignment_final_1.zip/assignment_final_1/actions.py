from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'
		
	def run(self, dispatcher, tracker, domain):
		count=0
		config={ "user_key":"5a5d2f716431b2107d3be309b8f22667"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'american':1,'bakery':5,'chinese':25,'cafe':30,'italian':55,'biryani':7,'mexican':73,'north indian':50,'south indian':85}
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)),'rating','desc', 5)
		d = json.loads(results)
		response=""
		if d['results_found'] == 0:
			response= "no results"
		else:
			for restaurant in d['restaurants']:
				if count ==5:
					break
				if budget=='Lesser than Rs 300' and restaurant['restaurant']['average_cost_for_two'] < 300:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+ str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1
				elif budget=='Rs 300 to 700' and restaurant['restaurant']['average_cost_for_two'] >= 300 and restaurant['restaurant']['average_cost_for_two'] <= 700:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+ str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1
				elif budget=='More than 700' and restaurant['restaurant']['average_cost_for_two'] > 700:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+ str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1

		if count==0:
			response=response+ " Oops!!!!! No restaurants found"
		dispatcher.utter_message("Top 5 "+cuisine+" restaurants in "+loc+" are:----")
		dispatcher.utter_message(response+"\n")
		SlotSet('retaurant_details',response)
		return [SlotSet('location',loc)]

class checkLocation(Action):
	def name(self):
		return 'check_location'


	def run(self, dispatcher, tracker, domain):
		
		loc = tracker.get_slot('location')
		loc_list=['Ahmedabad','Bengaluru','Chennai','Delhi','Hyderabad','Kolkata','Mumbai','Pune','Agra','Ajmer','Aligarh','Amravati','Amritsar','Asansol',
		'Aurangabad','Bareilly','Belgaum','Bhavnagar','Bhiwandi','Bhopal', 'Bhubaneswar', 'Bikaner','Bilaspur', 'Bokaro SteelCity','Chandigarh',
		'Coimbatore','Cuttack','Dehradun','Dhanbad','Bhilai','Durgapur','Dindigul','Erode','Faridabad','Firozabad','Ghaziabad','Gorakhpur',
		'Gulbarga','Guntur','Gwalior','Gurgaon','Guwahati','Hamirpur','Hubli–Dharwad','Indore','Jabalpur','Jaipur','Jalandhar','Jammu','Jamnagar',
		'Jamshedpur','Jhansi','Jodhpur','Kakinada','Kannur','Kanpur','Karnal','Kochi','Kolhapur','Kollam','Kozhikode','Kurnool','Ludhiana',
		'Lucknow','Madurai','Malappuram','Mathura','Mangalore','Meerut','Moradabad','Mysore','Nagpur','Nanded','Nashik','Nellore','Noida',
		'Patna','Pondicherry','Purulia','Prayagraj','Raipur','Rajkot','Rajahmundry','Ranchi','Rourkela','Salem','Sangli','Shimla',
		'Siliguri','Solapur','Srinagar','Surat','Thanjavur','Thiruvananthapuram','Thrissur','Tiruchirappalli','Tirunelveli', 'Ujjain','Bijapur',
		'Vadodara','Varanasi','Vasai-Virar City','Vijayawada','Visakhapatnam','Vellore','Warangal']
		check='true'
		print(loc)
		loc_list=[location.lower() for location in loc_list]
		if loc.lower() not in loc_list:
			dispatcher.utter_message("We do not operate in that area yet")
			check='false'
		else:
			check='true'
		return [SlotSet('check_loc',check)]

class sendMail(Action):
	def name(self):
		return 'send_email'

	def run(self, dispatcher, tracker, domain):
		count=0
		config={ "user_key":"5a5d2f716431b2107d3be309b8f22667"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'american':1,'bakery':5,'chinese':25,'cafe':30,'italian':55,'biryani':7,'mexican':73,'north indian':50,'south indian':85}
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)),'rating','desc', 5)
		d = json.loads(results)
		response="Top 10 "+cuisine+" restaurants in "+loc+" are :-----"
		if d['results_found'] == 0:
			response= "no results"
		else:
			for restaurant in d['restaurants']:
				if count ==10:
					break
				if budget=='Lesser than Rs 300' and restaurant['restaurant']['average_cost_for_two'] < 300:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1
				elif budget=='Rs 300 to 700' and restaurant['restaurant']['average_cost_for_two'] >= 300 and restaurant['restaurant']['average_cost_for_two'] <= 700:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+ str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1
				elif budget=='More than 700' and restaurant['restaurant']['average_cost_for_two'] > 700:
					response=response+" Restaurant "+str(count+1)+" : "+restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address'] + " with average budget( for 2 people) of "+ str(restaurant['restaurant']['average_cost_for_two']) +" has been rated "+str(restaurant['restaurant']['user_rating'].get('aggregate_rating'))+"\n"
					count =count+1
				
		if count==0:
			response=response+ " Oops!!!!! No restaurants found"
		email = tracker.get_slot('email')
		retaurant_details = tracker.get_slot('retaurant_details')
		#The mail addresses and password
		sender_address = 'afrozahappy25@gmail.com'#put your email id
		sender_pass = 'ABHappy@25'# password
		#Setup the MIME
		message = MIMEMultipart()
		message['From'] = sender_address
		message['To'] = email
		message['Subject'] = 'Restaurant details'   #The subject line
		#The body and the attachments for the mail
		message.attach(MIMEText(response, 'plain'))
		#Create SMTP session for sending the mail
		session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
		session.starttls() #enable security
		session.login(sender_address, sender_pass) #login with mail_id and password
		text = message.as_string()
		session.sendmail(sender_address, email, text)
		session.quit()
		dispatcher.utter_message("Mail Sent")




 
